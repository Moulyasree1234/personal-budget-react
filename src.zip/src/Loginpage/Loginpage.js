import React from 'react';

function Loginpage() {
  return (
    <div>
      Loginpage
    </div>
  );
}

export default Loginpage; 