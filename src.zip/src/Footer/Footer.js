import React from 'react';

function Footer() {
  return (
    <div className="bottom">
    <div className="center">
    Thank you for joining
    </div>
</div>
  );
}

export default Footer;