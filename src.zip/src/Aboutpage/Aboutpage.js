import React from 'react';

function Aboutpage() {
  return (
    <div>
      Aboutpage
    </div>
  );
}

export default Aboutpage;